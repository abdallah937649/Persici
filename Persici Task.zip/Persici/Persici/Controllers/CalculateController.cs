﻿using Layers.Persici.Layers.BLL.Interface;
using Microsoft.AspNetCore.Mvc;
using Persici.Server.Models;

namespace Persici.Server.Controllers
{


    [ApiController]
    [Route("[controller]")]
    public class CalculateController : ControllerBase
    {
        private readonly IVehicalService _carService;
        private readonly ICongestionTax _congestionTax;

        public CalculateController(IVehicalService carService,ICongestionTax congestionTax)
        {
            _carService = carService;
            _congestionTax = congestionTax;
        }

        [HttpGet("resport")]
        public async Task<IActionResult> Index(string cityId = "D16BAA67-F544-45B7-A6E7-F88BC76F99A2") 
        {
            try
            {
                //var cityId = Guid.Parse("D16BAA67-F544-45B7-A6E7-F88BC76F99A2");
                var cars = await _carService.GetAllWithLogAsync();
                //var report = await _congestionTax.GetTaxForOneDay(cars[0], cityId);
                var report = await _congestionTax.GetTaxForManyDays(cars[0], Guid.Parse(cityId));

                return Ok(report);
            }
            catch (Exception ex)
            {
                 return BadRequest(ex.Message);
            }
        }
    }
}
