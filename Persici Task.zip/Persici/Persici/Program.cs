using Layers.Persici.Layers.BLL.Interface;
using Layers.Persici.Layers.BLL;
using Layers.Persici.Layers.DAL.Repository;
using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.BLL;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DAL.Repository;
using Persici.Server.Models;
using Persici.Models.TollFreeService;
using Persici.Models.TollFreeService.TollFreeService;
using Persici.Models.IGetTaxMoney;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.
AddDbContext<PersiciDbContext>(options => options.
UseSqlServer(builder.Configuration.GetConnectionString(nameof(Basic.String.DefaultConnection))));
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IVehicalService, VehicalService>();
builder.Services.AddScoped<VehicalRepository>();
builder.Services.AddScoped<IVehicleTypeService, VehicleTypeService>();
builder.Services.AddScoped<VehicleTypeRepository>();
builder.Services.AddScoped<ICityService, CityService>();
builder.Services.AddScoped<CityRepository>();
builder.Services.AddScoped<ICityVehicleExemptionService, CityVehicleExemptionService>();
builder.Services.AddScoped<CityVehicleExemptionRepository>();
builder.Services.AddScoped<IVehicalLogService, VehicalLogService>();
builder.Services.AddScoped<VehicalLogRepository>();
builder.Services.AddScoped<IDurationService, DurationService>();
builder.Services.AddScoped<DurationRepository>();
builder.Services.AddScoped<IHolidayService, HolidayService>();
builder.Services.AddScoped<HolidayRepository>();
builder.Services.AddScoped<ICongestionTax, CongestionTaxCalculator>();
builder.Services.AddScoped<ICheckFreeService, CheckFreeService>();
builder.Services.AddScoped<IGetTaxMoney, GetTaxMoney>();


builder.Services.AddAutoMapper(typeof(MappingProfile));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
