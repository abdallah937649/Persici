﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.DAL.Repository
{
    public class DurationRepository
    {
        private readonly PersiciDbContext _context;

        public DurationRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblDuration>> GetAllForCityAsync(Guid cityId)
        {
            return await _context.TblDurations
                .AsNoTracking()
                .Where(d => d.CityId == cityId)
                .ToListAsync();
        }

        public async Task<TblDuration?> GetByIdAsync(Guid durationId)
        {
            return await _context.TblDurations.FirstOrDefaultAsync(c=> c.Id  == durationId);
        }

        public async Task<TblDuration?> GetByTimeAsync(DateTime dateTime)
        {
            var duration = await _context.TblDurations.Where(d => 

                (d.StartHour < dateTime.Hour || (d.StartHour == dateTime.Hour && d.StartMinute <= dateTime.Minute)) &&
                (d.EndHour > dateTime.Hour || (d.EndHour == dateTime.Hour && d.EndMinute >= dateTime.Minute)))

                .FirstOrDefaultAsync();

            return duration;
        }

        public async Task AddAsync(TblDuration duration)
        {
            await _context.TblDurations.AddAsync(duration);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(TblDuration duration)
        {
            _context.TblDurations.Update(duration);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid durationId)
        {
            var duration = await _context.TblDurations.FindAsync(durationId);
            if (duration != null)
            {
                _context.TblDurations.Remove(duration);
                await _context.SaveChangesAsync();
            }
        }

    }
}
