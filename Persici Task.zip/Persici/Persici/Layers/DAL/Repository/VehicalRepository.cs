﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Layers.Persici.Layers.DAL.Repository
{
    public class VehicalRepository
    {
        private readonly PersiciDbContext _context;

        public VehicalRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblVehical>> GetAllAsync()
        {
            return await _context.TblVehicals.AsNoTracking().ToListAsync();
        }

        public async Task<List<TblVehical>> GetAllWithLogAsync()
        {
            return await _context.TblVehicals.AsNoTracking().Include(c => c.TblVehicalLogs).Include(c=> c.TblVehicleType).AsSplitQuery().ToListAsync();
        }

        public async Task<TblVehical?> GetByIdAsync(Guid entityId)
        {
            return await _context.TblVehicals.FirstOrDefaultAsync(c=> c.Id  == entityId);
        }

        public async Task AddAsync(TblVehical entity)
        {
            await _context.TblVehicals.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(TblVehical entity)
        {
            _context.TblVehicals.Update(entity);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid entityId)
        {
            var entity = await _context.TblVehicals.FindAsync(entityId);
            if (entity != null)
            {
                _context.TblVehicals.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}
