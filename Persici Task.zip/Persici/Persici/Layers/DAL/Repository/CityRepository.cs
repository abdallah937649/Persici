﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.DAL.Repository
{
    public class CityRepository
    {
        private readonly PersiciDbContext _context;

        public CityRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblCity>> GetAllAsync()
        {
            return await _context.TblCities.AsNoTracking().ToListAsync();
        }

        public async Task<TblCity?> GetByIdAsync(Guid cityId)
        {
            return await _context.TblCities.FirstOrDefaultAsync(c=>  c.Id == cityId);
        }

        public async Task AddAsync(TblCity city)
        {
            await _context.TblCities.AddAsync(city);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(TblCity city)
        {
            _context.TblCities.Update(city);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid cityId)
        {
            var city = await _context.TblCities.FindAsync(cityId);
            if (city != null)
            {
                _context.TblCities.Remove(city);
                await _context.SaveChangesAsync();
            }
        }
    }
}
