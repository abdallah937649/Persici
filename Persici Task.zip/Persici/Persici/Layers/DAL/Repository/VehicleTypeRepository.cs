﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.DAL.Repository
{
    public class VehicleTypeRepository
    {
        private readonly PersiciDbContext _context;

        public VehicleTypeRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblVehicleType>> GetAllAsync()
        {
            return await _context.TblVehicleTypes.AsNoTracking().ToListAsync();
        }

        public async Task<TblVehicleType?> GetByIdAsync(Guid vehicleTypeId)
        {
            return await _context.TblVehicleTypes.FirstOrDefaultAsync(c => c.Id == vehicleTypeId);
        }

        public async Task AddAsync(TblVehicleType vehicleType)
        {
            await _context.TblVehicleTypes.AddAsync(vehicleType);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(TblVehicleType vehicleType)
        {
            _context.TblVehicleTypes.Update(vehicleType);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid vehicleTypeId)
        {
            var vehicleType = await GetByIdAsync(vehicleTypeId);
            if (vehicleType != null)
            {
                _context.TblVehicleTypes.Remove(vehicleType);
                await _context.SaveChangesAsync();
            }
        }
    }
}
