﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Layers.Persici.Layers.DAL.Repository
{
    public class VehicalLogRepository
    {
        private readonly PersiciDbContext _context;

        public VehicalLogRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblVehicalLog>> GetAllLogsAsync()
        {
            return await _context.TblVehicalLogs.Include(log => log.Vehical).AsNoTracking().ToListAsync();
        }

        public async Task<TblVehicalLog?> GetLogByIdAsync(Guid logId)
        {
            return await _context.TblVehicalLogs.FirstOrDefaultAsync(c=> c.Id == logId);
        }

        public async Task AddLogAsync(TblVehicalLog log)
        {
            await _context.TblVehicalLogs.AddAsync(log);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateLogAsync(TblVehicalLog log)
        {
            _context.TblVehicalLogs.Update(log);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteLogAsync(Guid logId)
        {
            var log = await _context.TblVehicalLogs.FindAsync(logId);
            if (log != null)
            {
                _context.TblVehicalLogs.Remove(log);
                await _context.SaveChangesAsync();
            }
        }
    }
}
