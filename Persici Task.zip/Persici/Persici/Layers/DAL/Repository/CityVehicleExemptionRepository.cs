﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.DAL.Repository
{
    public class CityVehicleExemptionRepository
    {
        private readonly PersiciDbContext _context;

        public CityVehicleExemptionRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblCityVehicleExemption>> GetAllForCityAsync(Guid cityId)
        {
            return await _context.TblCityVehicleExemptions.AsNoTracking().Where(e => e.CityId == cityId).ToListAsync();
        }

        public async Task<TblCityVehicleExemption?> GetByIdForCityVehicalTypeAsync(Guid cityId,Guid vehicleTypeId)
        {
            return await _context.TblCityVehicleExemptions.AsNoTracking().Where(e => e.CityId == cityId && e.VehicleTypeId == vehicleTypeId).FirstOrDefaultAsync();
        }

        public async Task<TblCityVehicleExemption?> GetByIdAsync(Guid exemptionId)
        {
            return await _context.TblCityVehicleExemptions.FirstOrDefaultAsync(c=> c.Id == exemptionId);
        }

        public async Task AddAsync(TblCityVehicleExemption exemption)
        {
            await _context.TblCityVehicleExemptions.AddAsync(exemption);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(TblCityVehicleExemption exemption)
        {
            _context.TblCityVehicleExemptions.Update(exemption);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid exemptionId)
        {
            var exemption = await _context.TblCityVehicleExemptions.FindAsync(exemptionId);
            if (exemption != null)
            {
                _context.TblCityVehicleExemptions.Remove(exemption);
                await _context.SaveChangesAsync();
            }
        }
    }
}
