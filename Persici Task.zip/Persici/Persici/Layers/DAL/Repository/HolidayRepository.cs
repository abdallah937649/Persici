﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.DAL.Repository
{
    public class HolidayRepository
    {
        private readonly PersiciDbContext _context;

        public HolidayRepository(PersiciDbContext context)
        {
            _context = context;
        }

        public async Task<List<TblHoliday>> GetAllAsync()
        {
            return await _context.TblHolidays.AsNoTracking().ToListAsync();
        }

        public async Task<List<TblHoliday>> GetAllForCityAsync(Guid cityId)
        {
            return await _context.TblHolidays.AsNoTracking().Where(h => h.CityId == cityId).ToListAsync();
        }

        public async Task<TblHoliday?> GetByIdAsync(Guid holidayId)
        {
            return await _context.TblHolidays.FirstOrDefaultAsync(c=> c.Id == holidayId);
        }

        public async Task AddAsync(TblHoliday holiday)
        {
            await _context.TblHolidays.AddAsync(holiday);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(TblHoliday holiday)
        {
            _context.TblHolidays.Update(holiday);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid holidayId)
        {
            var holiday = await _context.TblHolidays.FindAsync(holidayId);
            if (holiday != null)
            {
                _context.TblHolidays.Remove(holiday);
                await _context.SaveChangesAsync();
            }
        }
    }
}
