﻿namespace Persici.Server.Layers.DAL.EF;

public partial class TblCityVehicleExemption
{
    public Guid Id { get; set; }

    public Guid CityId { get; set; }

    public Guid VehicleTypeId { get; set; }

    public bool IsExempt { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual TblCity City { get; set; } = null!;

    public virtual TblVehicleType VehicleType { get; set; } = null!;
}
