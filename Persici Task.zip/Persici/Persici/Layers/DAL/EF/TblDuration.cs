﻿namespace Persici.Server.Layers.DAL.EF;

public partial class TblDuration
{
    public Guid Id { get; set; }

    public Guid? CityId { get; set; }

    public int? StartHour { get; set; }

    public int? StartMinute { get; set; }

    public int? EndHour { get; set; }

    public int? EndMinute { get; set; }

    public int? TaxAmount { get; set; }

    public virtual TblCity? City { get; set; }
}
