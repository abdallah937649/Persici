﻿namespace Persici.Server.Layers.DAL.EF;

public partial class TblCity
{
    public Guid Id { get; set; }

    public string? Name { get; set; }

    public int MaxTimeMinutelimite { get; set; }

    public int MaxTaxAmount { get; set; }

    public int YearLimite { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<TblCityVehicleExemption> TblCityVehicleExemptions { get; set; } = new List<TblCityVehicleExemption>();

    public virtual ICollection<TblDuration> TblDurations { get; set; } = new List<TblDuration>();

    public virtual ICollection<TblHoliday> TblHolidays { get; set; } = new List<TblHoliday>();
}
