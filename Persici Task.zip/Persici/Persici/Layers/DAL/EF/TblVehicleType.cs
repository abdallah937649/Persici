﻿namespace Persici.Server.Layers.DAL.EF;

public partial class TblVehicleType
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public virtual ICollection<TblCityVehicleExemption> TblCityVehicleExemptions { get; set; } = new List<TblCityVehicleExemption>();

    public virtual ICollection<TblVehical> TblVehicals { get; set; } = new List<TblVehical>();
}
