﻿namespace Persici.Server.Layers.DAL.EF;

public partial class TblVehical
{
    public Guid Id { get; set; }

    public string? Name { get; set; }

    public Guid? TypeId { get; set; }

    public virtual ICollection<TblVehicalLog> TblVehicalLogs { get; set; } = new List<TblVehicalLog>();

    public virtual TblVehicleType? TblVehicleType { get; set; }
}
