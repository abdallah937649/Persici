﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Persici.Server.Layers.DAL.EF;

public partial class PersiciDbContext : DbContext
{
    public PersiciDbContext()
    {
    }

    public PersiciDbContext(DbContextOptions<PersiciDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TblCity> TblCities { get; set; }

    public virtual DbSet<TblCityVehicleExemption> TblCityVehicleExemptions { get; set; }

    public virtual DbSet<TblDuration> TblDurations { get; set; }

    public virtual DbSet<TblHoliday> TblHolidays { get; set; }

    public virtual DbSet<TblVehical> TblVehicals { get; set; }

    public virtual DbSet<TblVehicalLog> TblVehicalLogs { get; set; }

    public virtual DbSet<TblVehicleType> TblVehicleTypes { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TblCity>(entity =>
        {
            entity.ToTable("Tbl_Cities");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Name)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
        });

        modelBuilder.Entity<TblCityVehicleExemption>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_City__3214EC07967EC0EE");

            entity.ToTable("Tbl_CityVehicleExemptions");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.City).WithMany(p => p.TblCityVehicleExemptions)
                .HasForeignKey(d => d.CityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Tbl_CityV__CityI__3B75D760");

            entity.HasOne(d => d.VehicleType).WithMany(p => p.TblCityVehicleExemptions)
                .HasForeignKey(d => d.VehicleTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Tbl_CityV__Vehic__3C69FB99");
        });

        modelBuilder.Entity<TblDuration>(entity =>
        {
            entity.ToTable("Tbl_Durations");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.City).WithMany(p => p.TblDurations)
                .HasForeignKey(d => d.CityId)
                .HasConstraintName("FK_Tbl_Durations_Tbl_Cities");
        });

        modelBuilder.Entity<TblHoliday>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_Holi__3214EC0733CAE774");

            entity.ToTable("Tbl_Holidays");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.HolidayDate).HasColumnType("datetime");
            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.City).WithMany(p => p.TblHolidays)
                .HasForeignKey(d => d.CityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Tbl_Holid__CityI__2E1BDC42");
        });

        modelBuilder.Entity<TblVehical>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_Tbl_Cars");

            entity.ToTable("Tbl_Vehicals");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.TblVehicleType).WithMany(p => p.TblVehicals)
                .HasForeignKey(d => d.TypeId)
                .HasConstraintName("FK_Tbl_Vehicals_Tbl_VehicleTypes");
        });

        modelBuilder.Entity<TblVehicalLog>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_Tbl_CarLogs");

            entity.ToTable("Tbl_VehicalLogs");

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.LogTime).HasColumnType("datetime");

            entity.HasOne(d => d.Vehical).WithMany(p => p.TblVehicalLogs)
                .HasForeignKey(d => d.VehicalId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Tbl_CarLogs_Tbl_Cars");
        });

        modelBuilder.Entity<TblVehicleType>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Tbl_Vehi__3214EC079AB5D296");

            entity.ToTable("Tbl_VehicleTypes");

            entity.Property(e => e.Id).HasDefaultValueSql("(newid())");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Name).HasMaxLength(255);
            entity.Property(e => e.UpdatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
