﻿using System;
using System.Collections.Generic;

namespace Persici.Server.Layers.DAL.EF;

public partial class TblVehicalLog
{
    public Guid Id { get; set; }

    public Guid VehicalId { get; set; }

    public DateTime LogTime { get; set; }

    public virtual TblVehical Vehical { get; set; } = null!;
}
