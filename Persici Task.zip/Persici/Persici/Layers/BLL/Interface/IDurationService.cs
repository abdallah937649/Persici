﻿using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Layers.BLL.Interface
{
    public interface IDurationService
    {
        Task<List<DurationDTO>> GetAllForCityAsync(Guid cityId);
        Task<TblDuration?> GetByIdAsync(Guid durationId);
        Task<TblDuration?> GetByTimeAsync(DateTime dateTime);
        Task AddAsync(TblDuration duration);
        Task UpdateAsync(TblDuration duration);
        Task DeleteAsync(Guid durationId);
    }
}
