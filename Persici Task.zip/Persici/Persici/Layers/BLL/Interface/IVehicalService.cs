﻿
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DTO;

namespace Layers.Persici.Layers.BLL.Interface
{
    public interface IVehicalService
    {
        Task<List<VehicalDTO>> GetAllAsync();
        Task<VehicalDTO?> GetByIdAsync(Guid entityId);
        Task<List<VehicalDTO>> GetAllWithLogAsync();
        Task AddAsync(TblVehical entity);
        Task UpdateAsync(TblVehical entity);
        Task DeleteAsync(Guid entityId);
    }
}
