﻿using Persici.Server.Layers.DAL.EF;

namespace Layers.Persici.Layers.BLL.Interface
{
    internal interface IVehicalLogService
    {
        Task<List<TblVehicalLog>> GetAllLogsAsync();
        Task<TblVehicalLog?> GetLogByIdAsync(Guid logId);
        Task AddLogAsync(TblVehicalLog log);
        Task UpdateLogAsync(TblVehicalLog log);
        Task DeleteLogAsync(Guid logId);
    }
}
