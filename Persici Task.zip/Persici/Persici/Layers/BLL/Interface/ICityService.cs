﻿using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Layers.BLL.Interface
{
    public interface ICityService
    {
        Task<List<TblCity>> GetAllCitiesAsync();
        Task<CityDTO?> GetCityByIdAsync(Guid cityId);
        Task AddCityAsync(TblCity city);
        Task UpdateCityAsync(TblCity city);
        Task DeleteCityAsync(Guid cityId);
    }
}
