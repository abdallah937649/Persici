﻿using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.BLL.Interface
{
    public interface ICityVehicleExemptionService
    {
        Task<List<TblCityVehicleExemption>> GetAllForCityAsync(Guid cityId);
        Task<TblCityVehicleExemption?> GetByIdForCityVehicalTypeAsync(Guid cityId, Guid vehicleTypeId);
        Task<TblCityVehicleExemption?> GetByIdAsync(Guid exemptionId);
        Task AddAsync(TblCityVehicleExemption exemption);
        Task UpdateAsync(TblCityVehicleExemption exemption);
        Task DeleteAsync(Guid exemptionId);
    }
}
