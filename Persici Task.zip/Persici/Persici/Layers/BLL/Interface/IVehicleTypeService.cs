﻿using Persici.Server.Layers.DAL.EF;

namespace Persici.Server.Layers.BLL.Interface
{
    public interface IVehicleTypeService
    {
        Task<List<TblVehicleType>> GetAllAsync();
        Task<TblVehicleType?> GetByIdAsync(Guid vehicleTypeId);
        Task AddAsync(TblVehicleType vehicleType);
        Task UpdateAsync(TblVehicleType vehicleType);
        Task DeleteAsync(Guid vehicleTypeId);
    }
}
