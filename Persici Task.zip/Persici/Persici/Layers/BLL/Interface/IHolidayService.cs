﻿using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Layers.BLL.Interface
{
    public interface IHolidayService
    {
        Task<List<HolidayDTO>> GetAllAsync();
        Task<List<TblHoliday>> GetAllForCityAsync(Guid cityId);
        Task<TblHoliday?> GetByIdAsync(Guid holidayId);
        Task AddAsync(TblHoliday holiday);
        Task UpdateAsync(TblHoliday holiday);
        Task DeleteAsync(Guid holidayId);
    }
}
