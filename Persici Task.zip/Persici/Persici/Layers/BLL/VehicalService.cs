﻿using AutoMapper;
using Layers.Persici.Layers.BLL.Interface;
using Layers.Persici.Layers.DAL.Repository;
using Microsoft.AspNetCore.Http.HttpResults;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DTO;
using Persici.Server.Models;

namespace Layers.Persici.Layers.BLL
{
    public class VehicalService : IVehicalService
    {
        private readonly VehicalRepository _carRepository;
        private readonly IMapper _mapper;

        public VehicalService(VehicalRepository entityRepository, IMapper mapper)
        {
            _carRepository = entityRepository;
            _mapper = mapper;
        }

        public async Task<List<VehicalDTO>> GetAllAsync()
        {
            var result = await _carRepository.GetAllAsync();
            return _mapper.Map<List<VehicalDTO>>(result);
        }

        public async Task<VehicalDTO> GetByIdAsync(Guid entityId)
        {
            var result = await _carRepository.GetByIdAsync(entityId);
            return _mapper.Map<VehicalDTO>(result);
        }

        public async Task AddAsync(TblVehical entity)
        {
            await _carRepository.AddAsync(entity);
        }

        public async Task UpdateAsync(TblVehical entity)
        {
            await _carRepository.UpdateAsync(entity);
        }

        public async Task DeleteAsync(Guid entityId)
        {
            await _carRepository.DeleteAsync(entityId);
        }

        public async Task<List<VehicalDTO>> GetAllWithLogAsync()
        {
            var result = await _carRepository.GetAllWithLogAsync();
            return _mapper.Map<List<VehicalDTO>>(result);
        }
    }
}
