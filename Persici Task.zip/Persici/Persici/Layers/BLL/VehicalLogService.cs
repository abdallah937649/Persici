﻿using Layers.Persici.Layers.BLL.Interface;
using Layers.Persici.Layers.DAL.Repository;
using Persici.Server.Layers.DAL.EF;

namespace Layers.Persici.Layers.BLL
{
    internal class VehicalLogService : IVehicalLogService
    {
        private readonly VehicalLogRepository _logRepository;

        public VehicalLogService(VehicalLogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public async Task<List<TblVehicalLog>> GetAllLogsAsync()
        {
            return await _logRepository.GetAllLogsAsync();
        }

        public async Task<TblVehicalLog?> GetLogByIdAsync(Guid logId)
        {
            return await _logRepository.GetLogByIdAsync(logId);
        }

        public async Task AddLogAsync(TblVehicalLog log)
        {
            await _logRepository.AddLogAsync(log);
        }

        public async Task UpdateLogAsync(TblVehicalLog log)
        {
            await _logRepository.UpdateLogAsync(log);
        }

        public async Task DeleteLogAsync(Guid logId)
        {
            await _logRepository.DeleteLogAsync(logId);
        }
    }
}
