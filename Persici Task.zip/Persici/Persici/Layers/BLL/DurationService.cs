﻿using AutoMapper;
using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DAL.Repository;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Layers.BLL
{
    public class DurationService : IDurationService
    {
        private readonly DurationRepository _durationsRepository;
        private readonly IMapper _mapper;

        public DurationService(DurationRepository durationsRepository,IMapper mapper)
        {
            _durationsRepository = durationsRepository;
            _mapper = mapper;
        }

        public async Task<List<DurationDTO>> GetAllForCityAsync(Guid cityId)
        {
            var data = await _durationsRepository.GetAllForCityAsync(cityId);
            return _mapper.Map<List<DurationDTO>>(data);
        }

        public async Task<TblDuration?> GetByIdAsync(Guid durationId)
        {
            return await _durationsRepository.GetByIdAsync(durationId);
        }
        
        public async Task<TblDuration?> GetByTimeAsync(DateTime dateTime)
        {
            return await _durationsRepository.GetByTimeAsync(dateTime);
        }

        public async Task  AddAsync(TblDuration duration)
        {
            await _durationsRepository.AddAsync(duration);
        }

        public async Task UpdateAsync(TblDuration duration)
        {
            await _durationsRepository.UpdateAsync(duration);
        }

        public async Task DeleteAsync(Guid durationId)
        {
            await _durationsRepository.DeleteAsync(durationId);
        }
    }
}
