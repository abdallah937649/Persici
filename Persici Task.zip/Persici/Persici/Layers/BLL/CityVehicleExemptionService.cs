﻿using Microsoft.EntityFrameworkCore;
using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DAL.Repository;

namespace Persici.Server.Layers.BLL
{
    public class CityVehicleExemptionService : ICityVehicleExemptionService
    {
        private readonly CityVehicleExemptionRepository _cityVehicleExemptionRepository;

        public CityVehicleExemptionService(CityVehicleExemptionRepository cityVehicleExemptionRepository)
        {
            _cityVehicleExemptionRepository = cityVehicleExemptionRepository;
        }

        public async Task<List<TblCityVehicleExemption>> GetAllForCityAsync(Guid exemptionId)
        {
            return await _cityVehicleExemptionRepository.GetAllForCityAsync(exemptionId);
        }

        public async Task<TblCityVehicleExemption?> GetByIdForCityVehicalTypeAsync(Guid cityId, Guid vehicleTypeId)
        {
            return await _cityVehicleExemptionRepository.GetByIdForCityVehicalTypeAsync(cityId,vehicleTypeId);
        }

        public async Task<TblCityVehicleExemption?> GetByIdAsync(Guid exemptionId)
        {
            return await _cityVehicleExemptionRepository.GetByIdAsync(exemptionId);
        }

        public async Task AddAsync(TblCityVehicleExemption exemption)
        {
            await _cityVehicleExemptionRepository.AddAsync(exemption);
        }

        public async Task UpdateAsync(TblCityVehicleExemption exemption)
        {
            await _cityVehicleExemptionRepository.UpdateAsync(exemption);
        }

        public async Task DeleteAsync(Guid exemptionId)
        {
            await _cityVehicleExemptionRepository.DeleteAsync(exemptionId);
        }
    }
}
