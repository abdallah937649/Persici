﻿using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DAL.Repository;

namespace Persici.Server.Layers.BLL
{
    public class VehicleTypeService : IVehicleTypeService
    {
        private readonly VehicleTypeRepository _vehicleTypeRepository;

        public VehicleTypeService(VehicleTypeRepository vehicleTypeRepository)
        {
            _vehicleTypeRepository = vehicleTypeRepository;
        }

        public async Task<List<TblVehicleType>> GetAllAsync()
        {
            return await _vehicleTypeRepository.GetAllAsync();
        }

        public async Task<TblVehicleType?> GetByIdAsync(Guid vehicleTypeId)
        {
            return await _vehicleTypeRepository.GetByIdAsync(vehicleTypeId);
        }

        public async Task AddAsync(TblVehicleType vehicleType)
        {
            await _vehicleTypeRepository.AddAsync(vehicleType);
        }

        public async Task UpdateAsync(TblVehicleType vehicleType)
        {
            await _vehicleTypeRepository.UpdateAsync(vehicleType);
        }

        public async Task DeleteAsync(Guid vehicleTypeId)
        {
            await _vehicleTypeRepository.DeleteAsync(vehicleTypeId);
        } 
    }
}
