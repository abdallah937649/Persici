﻿using AutoMapper;
using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DAL.Repository;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Layers.BLL
{
    public class HolidayService : IHolidayService
    {
        private readonly HolidayRepository _holidayRepository;
        private readonly IMapper _mapper;

        public HolidayService(HolidayRepository holidayRepository,IMapper mapper)
        {
            _holidayRepository = holidayRepository;
            _mapper = mapper;
        }

        public async Task<List<HolidayDTO>> GetAllAsync()
        {
            var data = await _holidayRepository.GetAllAsync();
            return _mapper.Map< List<HolidayDTO>>(data);
        }

        public async Task<List<TblHoliday>> GetAllForCityAsync(Guid cityId)
        {
            return await _holidayRepository.GetAllForCityAsync(cityId);
        }

        public async Task<TblHoliday?> GetByIdAsync(Guid holidayId)
        {
            return await _holidayRepository.GetByIdAsync(holidayId);
        }

        public async Task AddAsync(TblHoliday holiday)
        {
            await _holidayRepository.AddAsync(holiday);
        }

        public async Task UpdateAsync(TblHoliday holiday)
        {
            await _holidayRepository.UpdateAsync(holiday);
        }

        public async Task DeleteAsync(Guid holidayId)
        {
            await _holidayRepository.DeleteAsync(holidayId);
        }
    }
}
