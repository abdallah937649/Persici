﻿using AutoMapper;
using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DAL.Repository;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Layers.BLL
{
    public class CityService : ICityService
    {
        private readonly CityRepository _cityRepository;
        private readonly IMapper _mapper;

        public CityService(CityRepository cityRepository,IMapper mapper)
        {
            _cityRepository = cityRepository;
            _mapper = mapper;
        }

        public async Task<List<TblCity>> GetAllCitiesAsync()
        {
            return await _cityRepository.GetAllAsync();
        }

        public async Task<CityDTO?> GetCityByIdAsync(Guid cityId)
        {
            var data = await _cityRepository.GetByIdAsync(cityId);
            return _mapper.Map<CityDTO>(data);
        }

        public async Task AddCityAsync(TblCity city)
        {
            await _cityRepository.AddAsync(city);
        }

        public async Task UpdateCityAsync(TblCity city)
        {
            await _cityRepository.UpdateAsync(city);
        }

        public async Task DeleteCityAsync(Guid cityId)
        {
            await _cityRepository.DeleteAsync(cityId);
        }
    }
}
