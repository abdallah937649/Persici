﻿namespace Persici.Server.Layers.DTO
{
    public class VehicalDTO
    {
        public Guid Id { get; set; }  
        public string Name { get; set; }  
        public Guid TypeId { get; set; }  
        public VehicalLogDTO[]? VehicalLog { get; set; }
        public VehicleTypeDTO? VehicleType { get; set; }
    }
}
