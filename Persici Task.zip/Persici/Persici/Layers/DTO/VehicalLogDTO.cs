﻿namespace Persici.Server.Layers.DTO
{
    public class VehicalLogDTO
    {
        public Guid Id { get; set; } 
        public Guid VehicalId { get; set; }  
        public DateTime LogTime { get; set; } 
    }
}
