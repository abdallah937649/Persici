﻿namespace Persici.Server.Layers.DTO
{
    public class HolidayDTO
    {
        public Guid Id { get; set; }  
        public Guid CityId { get; set; }  
        public DateTime? HolidayDate { get; set; }  
        public bool? IsBeforeHoliday { get; set; }  
        public string Description { get; set; }  
        public DateTime CreatedAt { get; set; }  
        public DateTime UpdatedAt { get; set; } 
        public int? Type { get; set; } 
        public int? Month { get; set; } 
        public int? DayOfWeeek { get; set; }  
    }
}
