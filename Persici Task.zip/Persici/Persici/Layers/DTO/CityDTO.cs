﻿namespace Persici.Server.Layers.DTO
{
    public class CityDTO
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int MaxTimeMinutelimite { get; set; }
        public int MaxTaxAmount { get; set; }
        public int YearLimite { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
