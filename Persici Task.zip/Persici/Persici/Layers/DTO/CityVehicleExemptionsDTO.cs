﻿namespace Persici.Server.Layers.DTO
{
    public class CityVehicleExemptionsDTO
    {
        public Guid Id { get; set; }
        public Guid CityId { get; set; }
        public Guid VehicleTypeId { get; set; }
        public bool IsExempt { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
