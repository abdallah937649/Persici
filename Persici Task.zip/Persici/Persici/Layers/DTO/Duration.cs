﻿namespace Persici.Server.Layers.DTO
{
    public class DurationDTO
    {
        public Guid Id { get; set; } // Unique identifier for each time period
        public Guid CityId { get; set; } // Foreign key for the city
        public int StartHour { get; set; } // Start hour for the time range
        public int StartMinute { get; set; } // Start minute for the time range
        public int EndHour { get; set; } // End hour for the time range
        public int EndMinute { get; set; } // End minute for the time range

         


        public int TaxAmount { get; set; } // Tax amount for this time range
    }
}
