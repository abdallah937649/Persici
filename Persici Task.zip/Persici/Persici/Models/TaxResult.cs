﻿namespace Persici.Models
{
    public class TaxResult
    {
        public string VehicleName { get; set; }
        public DateTime Day { get; set; }
        public int TotalFee { get; set; }
    }
}
