﻿using Persici.Models;
using Persici.Server.Layers.DTO;

namespace Persici.Server.Models
{
    public interface ICongestionTax
    {
        /*Check Please (For One Day)*/
        //Task<TaxResult> GetTaxForOneDay(VehicalDTO vehicle, Guid cityId);
        Task<List<TaxResult>> GetTaxForManyDays(VehicalDTO vehicle, Guid cityId);
    }
}
