﻿using AutoMapper;
using Persici.Server.Layers.DAL.EF;
using Persici.Server.Layers.DTO;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Persici.Server.Models
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {

            CreateMap<TblVehical, VehicalDTO>()
          .ForMember(dest => dest.VehicalLog, opt => opt.MapFrom(src => src.TblVehicalLogs))
          .ForMember(dest => dest.VehicleType, opt => opt.MapFrom(src => src.TblVehicleType)); // مابينج لنوع السيارة

            // Mapping from VehicalDTO to TblVehical
            CreateMap<VehicalDTO, TblVehical>()
                .ForMember(dest => dest.TblVehicalLogs, opt => opt.MapFrom(src => src.VehicalLog))
                .ForMember(dest => dest.TblVehicleType, opt => opt.MapFrom(src => src.VehicleType)); // مابينج لنوع السيارة

            // Mapping from TblVehicalLog to VehicalLogDTO
            CreateMap<TblVehicalLog, VehicalLogDTO>();

            // Mapping from VehicalLogDTO to TblVehicalLog
            CreateMap<VehicalLogDTO, TblVehicalLog>()
                .ForMember(dest => dest.Vehical, opt => opt.Ignore());

            // Mapping from TblVehicalType to VehicalTypeDTO
            CreateMap<TblVehicleType, VehicleTypeDTO>();

            // Mapping from VehicalTypeDTO to TblVehicalType
            CreateMap<VehicleTypeDTO, TblVehicleType>();


            // Mapping from TblDuration to DurationDTO
            CreateMap<TblDuration, DurationDTO>();

            // Mapping from DurationDTO to TblDuration
            CreateMap<DurationDTO, TblDuration>();

            // Mapping from TblCity to CityDTO
            CreateMap<TblCity, CityDTO>();

            // Mapping from CityDTO to TblCity
            CreateMap<CityDTO, TblCity>();


            // Mapping from TblHoliday to HolidayDTO
            CreateMap<TblHoliday, HolidayDTO>();

            // Mapping from HolidayDTO to TblHoliday
            CreateMap<HolidayDTO, TblHoliday>();
        }
    }
}
