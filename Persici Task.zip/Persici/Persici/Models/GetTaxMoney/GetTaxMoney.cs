﻿using Persici.Models.TollFreeService;
using Persici.Server.Layers.DTO;

namespace Persici.Models.IGetTaxMoney
{
    public class GetTaxMoney : IGetTaxMoney
    {
        private readonly ICheckFreeService _checkFreeService;

        public GetTaxMoney(ICheckFreeService checkFreeService)
        {
            _checkFreeService = checkFreeService;
        }

        public async Task<int> GetTollFee(
           DateTime date,
           VehicalDTO vehicle,
           CityDTO city,
           List<DurationDTO> durations,
           List<HolidayDTO> holidays
           )
        {
            var tollFreeDateTask = _checkFreeService.IsTollFreeDate(date, city, holidays);
            var tollFreeVehicleTask = _checkFreeService.IsTollFreeVehicle(vehicle, city.Id);

            await Task.WhenAll(tollFreeDateTask, tollFreeVehicleTask);

            if (tollFreeDateTask.Result || tollFreeVehicleTask.Result)
                return 0;

            var applicableDuration = durations.FirstOrDefault(d =>
                       (date.Hour > d.StartHour || (date.Hour == d.StartHour && date.Minute >= d.StartMinute)) &&
                       (date.Hour < d.EndHour || (date.Hour == d.EndHour && date.Minute <= d.EndMinute)));

            return applicableDuration?.TaxAmount ?? 0;
        }
    }
}
