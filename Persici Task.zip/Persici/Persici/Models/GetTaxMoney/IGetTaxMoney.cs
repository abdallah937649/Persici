﻿using Persici.Server.Layers.DTO;

namespace Persici.Models.IGetTaxMoney
{
    public interface IGetTaxMoney
    {
        Task<int> GetTollFee(DateTime date,VehicalDTO vehicle,CityDTO city,List<DurationDTO> durations,List<HolidayDTO> holidays);
    }
}
