﻿using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DTO;
using Persici.Server.Models;
using static Persici.Server.Models.Basic;

namespace Persici.Models.TollFreeService.TollFreeService
{
    // TollFreeService: المسؤول عن التحقق إذا كانت المركبة معفاة
    public class CheckFreeService : ICheckFreeService
    {
        private readonly ICityVehicleExemptionService _cityVehicales;

        public CheckFreeService(ICityVehicleExemptionService cityVehicales)
        {
            _cityVehicales = cityVehicales;
        }

        public async Task<bool> IsTollFreeVehicle(VehicalDTO vehicle, Guid cityId)
        {
            if (vehicle == null) return false;

            var freeVehicales = await _cityVehicales.GetByIdForCityVehicalTypeAsync(cityId, vehicle.VehicleType.Id);

            return freeVehicales != null ? freeVehicales.IsExempt : false;
        }

        public async Task<bool> IsTollFreeDate(DateTime date, CityDTO city, List<HolidayDTO> holidays)
        {
            var isHoliday = holidays.Exists(h =>
                                    h.Type == (int)Basic.HolidayType.Date &&
                                    h.HolidayDate.HasValue &&
                                    h.HolidayDate.Value.Date.AddDays(-1) == date.Date &&
                                    h.IsBeforeHoliday.HasValue && h.IsBeforeHoliday.Value);

            if (isHoliday)
                return true;

            isHoliday = holidays.Exists(holiday => holiday.HolidayDate?.Date == date.Date);

            if (isHoliday)
                return true;

            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                return true;

            isHoliday = holidays.Exists(holiday => holiday.Month == date.Month && (Basic.HolidayType)holiday.Type == Basic.HolidayType.Month);

            if (isHoliday)
                return true;

            isHoliday = holidays.Exists(holiday => holiday.DayOfWeeek == (int)date.DayOfWeek && (Basic.HolidayType)holiday.Type == Basic.HolidayType.DayOfWeek);

            if (isHoliday)
                return true; 

            return false;
        } 
    }
}
