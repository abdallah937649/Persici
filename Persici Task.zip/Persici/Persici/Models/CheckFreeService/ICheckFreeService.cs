﻿using Persici.Server.Layers.BLL.Interface;
using Persici.Server.Layers.DTO;

namespace Persici.Models.TollFreeService
{
    public interface ICheckFreeService
    {
        Task<bool> IsTollFreeVehicle(VehicalDTO vehicle, Guid cityId);

        Task<bool> IsTollFreeDate(DateTime date, CityDTO city, List<HolidayDTO> holidays);
    }
}
