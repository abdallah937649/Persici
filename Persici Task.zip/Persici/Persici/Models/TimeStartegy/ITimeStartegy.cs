﻿namespace Persici.Server.Models.TimeStartegy
{
    public interface ITimeStartegy
    {
        bool CheckTimeLimite(int minutes, int MaxLimite);

        int CalculateBasedOnTimeLimite(int nextTax, int firstTax, int totalFee);
    }
}
