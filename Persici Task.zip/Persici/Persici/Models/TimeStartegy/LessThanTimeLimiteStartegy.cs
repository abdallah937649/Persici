﻿namespace Persici.Server.Models.TimeStartegy
{
    public class LessThanTimeLimiteStartegy : ITimeStartegy
    {
        public int CalculateBasedOnTimeLimite(int nextTax, int firstTax, int totalTax)
        {
            var maxTax = (nextTax > firstTax) ? nextTax : firstTax;

            if (maxTax == nextTax)
                totalTax += (maxTax - firstTax);

            return totalTax;
        }

        public bool CheckTimeLimite(int minutes, int MaxLimite)=>
            minutes <= MaxLimite;
    }
}
