﻿namespace Persici.Server.Models.TimeStartegy
{
    public class MoreThanTimelimiteStartegy : ITimeStartegy
    {
        public int CalculateBasedOnTimeLimite(int nextTax, int firstTax, int totalTax)
        {
            return totalTax += nextTax;
        }

        public bool CheckTimeLimite(int minutes, int MaxLimite) =>
            (minutes > MaxLimite);
    }
}
