﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persici.Server.Models
{
    public static class Basic
    {
        public enum String
        {
            DefaultConnection
        }

        public enum HolidayType
        {
            None,
            DayOfWeek = 1,
            Date = 2,
            Month = 3,
        } 
    }
}
