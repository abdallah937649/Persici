﻿using Persici.Server.Layers.DTO;
using Persici.Server.Models.TimeStartegy;
using Persici.Server.Layers.BLL.Interface;
using Persici.Models;
using Persici.Models.IGetTaxMoney;

namespace Persici.Server.Models
{
    public class CongestionTaxCalculator : ICongestionTax
    {
        private readonly ICityVehicleExemptionService _cityVehicales;
        private readonly IDurationService _duration;
        private readonly IHolidayService _holidays;
        private readonly IGetTaxMoney _getTaxMoney;
        private readonly ICityService _city;

        public CongestionTaxCalculator(
            ICityVehicleExemptionService cityVehicales,
            IGetTaxMoney getTaxMoney,
            IDurationService duration,
            IHolidayService holidy,
            ICityService city
            )
        {
            _getTaxMoney = getTaxMoney;
            _cityVehicales = cityVehicales;
            _duration = duration;
            _holidays = holidy;
            _city = city;
        }

        /*(For Many Days)*/
        public async Task<List<TaxResult>> GetTaxForManyDays(VehicalDTO vehicle, Guid cityId)
        {
            var times = vehicle.VehicalLog.Select(c => c.LogTime).Order();
            var durations = await _duration.GetAllForCityAsync(cityId);
            var holidays = await _holidays.GetAllAsync();
            var city = await _city.GetCityByIdAsync(cityId);
            var groupedByDay = times.Where(c => c.Year == city?.YearLimite).GroupBy(t => t.Date);
            int maxLimitTax = city.MaxTaxAmount;
            int maxLimitTime = city.MaxTimeMinutelimite;

            List<TaxResult> taxResults = new List<TaxResult>();

            foreach (var dayGroup in groupedByDay)
            {

                var intervalStart = dayGroup.FirstOrDefault();
                var firstTax = await _getTaxMoney.GetTollFee(intervalStart, vehicle, city, durations, holidays);
                int totalFeeForDay = firstTax; 

                ITimeStartegy _timeStrategy;

                foreach (var date in dayGroup.Skip(1))
                {
                    var nextFee = await _getTaxMoney.GetTollFee(date, vehicle, city, durations, holidays);

                    _timeStrategy =
                        Math.Abs((date - intervalStart).TotalMinutes) <= maxLimitTime ?
                        new LessThanTimeLimiteStartegy() :
                        new MoreThanTimelimiteStartegy();

                    var result = _timeStrategy.CalculateBasedOnTimeLimite(nextFee, firstTax, totalFeeForDay);

                    if (result >= maxLimitTax)
                    {
                        totalFeeForDay = maxLimitTax;
                        break;
                    }

                    totalFeeForDay = result;
                }

                taxResults.Add(new TaxResult
                {
                    VehicleName = vehicle.Name,
                    Day = dayGroup.Key,
                    TotalFee = totalFeeForDay
                });
            }

            return taxResults;
        }

        /*Check Please (For One Day)*/
        #region Calculation For One Day
        //public async Task<TaxResult> GetTaxForOneDay(VehicalDTO vehicle, Guid cityId)
        //{
        //    var times = vehicle.VehicalLog.Select(c => c.LogTime).Order();
        //    var intervalStart = times.FirstOrDefault();
        //    var durations = await _duration.GetAllForCityAsync(cityId);
        //    var holidays = await _holidays.GetAllAsync();
        //    var city = await _city.GetCityByIdAsync(cityId);
        //    var firstTax = await _getTaxMoney.GetTollFee(intervalStart, vehicle, city, durations, holidays);
        //    int totalFee = firstTax, maxLimitTax = 60, maxLimitTime = 60;
        //    ITimeStartegy _timeStrategy;

        //    foreach (var date in times.Skip(1))
        //    {
        //        var nextFee = await _getTaxMoney.GetTollFee(date, vehicle, city, durations, holidays);

        //        _timeStrategy =
        //            Math.Abs((date - intervalStart).TotalMinutes) <= maxLimitTime ?
        //            new LessThanTimeLimiteStartegy() :
        //            new MoreThanTimelimiteStartegy();

        //        var result = _timeStrategy.CalculateBasedOnTimeLimite(nextFee, firstTax, totalFee);

        //        if (result >= maxLimitTax)
        //        {
        //            result = maxLimitTax;
        //            break;
        //        }

        //        totalFee = result;
        //    }

        //    //return totalFee;

        //    return new TaxResult
        //    {
        //        VehicleName = vehicle.Name,
        //        Day = intervalStart.Date,
        //        TotalFee = totalFee
        //    };
        //}
        #endregion
    }
}

